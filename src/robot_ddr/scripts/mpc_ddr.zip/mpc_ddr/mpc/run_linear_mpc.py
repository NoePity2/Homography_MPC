import casadi as opt
import numpy as np
import matplotlib.pyplot as plt
import mpc_ddr.utils.LinearFormulation as LF
import mpc_ddr.utils.Robot as Robot
from mpc_ddr.mpc.lmpc import Orientation, Position
from mpc_ddr.params.linear_params import orientation_params, position_params
import time

T = 0.1 # Time horizon
N = 15 # number of control intervals

# =============== References values ===============

# ============== Linear parameters ==============
X_ref  = (3.0)*np.ones((N,1)) # Vector
Y_ref  = (3.0)*np.ones((N,1)) # Vector
state_vector = np.array([[0],[0]])
x  = np.zeros( (3,1) ) 

Ppsx_m = LF.Ppsx(N)
Ppsy_m = LF.Ppsy(N)

Pput_m = LF.Pput(N,T)
Ppst_m = LF.Ppst(N)

params_position = position_params()
Position_opt = Position(params_position,N,T)

# =============== Orientation Optimization ===============
Tethas_ref = 45*(np.pi/180)*np.ones((N,1)) # Vector
params_orientation = orientation_params()
Orientation_opt = Orientation(params_orientation,N,T)
theta_k = 0*(np.pi/180)

Xk1  = np.zeros(N) # Vector
Yk1  = np.zeros(N) # Vector
#Thetas_OMN = LF.Get_Thetas_OMN(Xk1,Yk1)

x_new = np.array( [ [0],[0],[0]] )

dt = 0.1
t0 = 0
tf = 30
times = np.arange(t0,tf,dt)
trajectory = np.zeros(( 3, len(times) )) 

start_time = time.time()
#============= Ciclo de navegación ============
for j in range(len(times)):
   # ============ Optimization for angular velocities =================
   Thetas_OMN = LF.Get_Thetas_OMN(Xk1,Yk1) # se queda en el ciclo
   Orientation_opt.solve(Thetas_OMN,Tethas_ref,theta_k)
   Omega_opt = Orientation_opt.get_solution()

   Theta  = LF.Get_angles_from_optimization(Ppst_m,theta_k,Pput_m,Omega_opt)

   # =============== Optimization for linear velocities ===============
   Position_opt.solve(state_vector,Theta,X_ref,Y_ref)
   V_opt = Position_opt.get_solution()

   Ppux_m = LF.Ppux(N,T,Theta)
   Ppuy_m = LF.Ppuy(N,T,Theta)

   # ============= Get horizon trajectories ==============
   Xk1 = LF.Get_X_k1_vector(Ppsx_m,Ppux_m,state_vector,V_opt)
   Yk1 = LF.Get_Y_k1_vector(Ppsy_m,Ppuy_m,state_vector,V_opt)

   u = np.array([ V_opt[0], Omega_opt[0]  ])
   x = Robot.robot_ddr(x_new,u,dt)
   print( "x = ", x )
   state_vector = np.array([  x[0] , x[1]  ]) 
   theta_k = x[2]
   x_new = x

   trajectory[0][j] = x[0]
   trajectory[1][j] = x[1]
   trajectory[2][j] = x[2]

end_time = time.time()
execution_time = end_time - start_time 
print("Execution time:",execution_time)

robot = Robot.dib_robot([trajectory[0,-1],trajectory[1,-1],trajectory[2,-1]],0.05)

fig = plt.figure(figsize=(8,6))
ax1 = fig.add_subplot(2,2,1)
ax1.plot(robot[:,0],robot[:,1],'r-',alpha=0.25)
ax1.plot(trajectory[0,:],trajectory[1,:])
ax1.grid()
ax1.set_xlabel("x-coordinate")
ax1.set_ylabel("y-coordinate")
ax1.set_aspect("equal")

ax2 = fig.add_subplot(2,2,2)
ax2.plot(times,trajectory[0])
ax2.grid()
ax2.set_xlabel("time [s]")
ax2.set_ylabel("x-coordinate")

ax3 = fig.add_subplot(2,2,3)
ax3.plot(times,trajectory[1])
ax3.grid()
ax3.set_xlabel("time [s]")
ax3.set_ylabel("y-coordinate")

ax4 = fig.add_subplot(2,2,4)
ax4.plot(times,trajectory[2]*(180/np.pi))
ax4.grid()
ax4.set_xlabel("time [s]")
ax4.set_ylabel("Orientation [deg]")

plt.show()

