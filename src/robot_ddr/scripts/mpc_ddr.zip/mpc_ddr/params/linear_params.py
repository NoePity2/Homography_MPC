__author__ = 'Noe Aldana'
__email__ = 'noe.aldana@iberoleon.mx'

def orientation_params():

	delta = 0.6  # angle limit
	alpha = 1e-4 # qp gain
	beta  = 2e-2 # qp gain
	lbO   = -1.81829 # lower angular velocity constraint
	ubO   = 1.81829 # upper angular velocity constraint

	params = {
		'delta': delta,
		'alpha': alpha,
		'beta' : beta,
		'lbO'  : lbO,
		'ubO'  : ubO,
	}

	return params

def position_params():

	alpha1 = 0.1
	alpha2 = 1.2e-1
	alpha3 = 1.2e-1
	lbv    = -0.26 # lower angular velocity constraint
	ubv    = 0.26 # upper angular velocity constraint

	params = {
		'alpha1': alpha1,
		'alpha2': alpha2,
		'alpha3': alpha3,
		'lbv'   : lbv,
		'ubv'   : ubv,
	}

	return params




